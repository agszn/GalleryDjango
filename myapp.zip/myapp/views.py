from django.shortcuts import render, redirect,  get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages

from .forms import *
from .models import *
from django.db.models import Q

from django.http import JsonResponse
from django.conf import settings
import os

import joblib
import numpy as np

def base(request):
    return render(request, 'base.html')

def about(request):
    return render(request, 'about/about.html')

def register(request):
    if request.method == 'POST':
        user_form = UserRegistrationForm(request.POST)
        if user_form.is_valid():
            #create a new registration object and avoid saving it yet
            new_user = user_form.save(commit=False)
            #reset the choosen password
            new_user.set_password(user_form.cleaned_data['password'])
            #save the new registration
            new_user.save()
            return render(request, 'registration/register_done.html',{'new_user':new_user})
    else:
        user_form = UserRegistrationForm()
    return render(request, 'registration/register.html',{'user_form':user_form})

def profile(request):
    return render(request, 'profile/profile.html')



@login_required
def edit_profile(request):
    if request.method == 'POST':
        user_form = EditProfileForm(request.POST, request.FILES, instance=request.user)
        if user_form.is_valid():
            user = user_form.save()
            profile = user.profile
            if 'profile_picture' in request.FILES:
                profile.profile_picture = request.FILES['profile_picture']
            profile.save()
            messages.success(request, 'Your profile was successfully updated!')
            return redirect('profile')
    else:
        user_form = EditProfileForm(instance=request.user)
    
    return render(request, 'profile/edit_profile.html', {'user_form': user_form})

@login_required
def delete_account(request):
    if request.method == 'POST':
        request.user.delete()
        messages.success(request, 'Your account was successfully deleted.')
        return redirect('base')  # Redirect to the homepage or another page after deletion

    return render(request, 'registration/delete_account.html')
# das
@login_required
def dashboard(request):
    users_count = User.objects.all().count()
    consumers = Consumer.objects.all().count

    context = {
        'users_count':users_count,
        'consumers':consumers,
    }
    return render(request, "dashboard/dashboard.html", context=context)
#CRUD operations start here
@login_required
def dashvalues(request):
    consumers = Consumer.objects.all()
    search_query = ""
    
    if request.method == "POST": 
        if "create" in request.POST:
            name = request.POST.get("name")
            email = request.POST.get("email")
            image = request.FILES.get("image")
            content = request.POST.get("content")

            Consumer.objects.create(
                name=name,
                email=email,
                image=image,
                content=content
            )
            messages.success(request, "Consumer added successfully")
    
        elif "update" in request.POST:
            id = request.POST.get("id")
            name = request.POST.get("name")
            email = request.POST.get("email")
            image = request.FILES.get("image")
            content = request.POST.get("content")

            consumer = get_object_or_404(Consumer, id=id)
            consumer.name = name
            consumer.email = email
            consumer.image = image
            consumer.content = content
            consumer.save()
            messages.success(request, "Consumer updated successfully")
    
        elif "delete" in request.POST:
            id = request.POST.get("id")
            Consumer.objects.get(id=id).delete()
            messages.success(request, "Consumer deleted successfully")
        
        elif "search" in request.POST:
            search_query = request.POST.get("query")
            consumers = Consumer.objects.filter(Q(name__icontains=search_query) | Q(email__icontains=search_query))

    context = {
        "consumers": consumers, 
        "search_query": search_query
    }
    return render(request, "crud/dashvalue.html", context=context)
# CRUD operations end here

# Contact start
@login_required
def contact(request):
    if request.method == 'POST':
        form = ContactForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Thank you for contacting us!")
            return redirect('dashboard')  # Redirect to the same page to show the modal
    else:
        form = ContactForm()

    return render(request, 'contact/contact_form.html', {'form': form})
# contact end
# views.py
from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.db.models import Q
from .models import Image, Like, Dislike, Comment
from .forms import ImageForm, CommentForm
from itertools import groupby
from django.db.models import F

@login_required
def image_list(request):
    query = request.GET.get('q')
    if query:
        images = Image.objects.filter(Q(title__icontains=query) | Q(description__icontains=query))
    else:
        images = Image.objects.all()

    # Sort the images by title to group them
    images = images.order_by('title')

    # Group by title and take only the first image of each group
    unique_images = []
    for title, group in groupby(images, key=lambda x: x.title):
        unique_images.append(next(group))

    for image in unique_images:
        image.properties = image.get_image_properties()

    return render(request, 'gallery/image_list.html', {'images': unique_images})


from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from .models import Image, Like, Dislike, Comment
from .forms import CommentForm
from django.db.models import Q
from PIL import Image as PilImage
from PIL import Image as PilImage

@login_required
def image_detail(request, pk):
    image = get_object_or_404(Image, pk=pk)
    comments = image.comments.all()
    user_like = Like.objects.filter(image=image, user=request.user).exists()
    user_dislike = Dislike.objects.filter(image=image, user=request.user).exists()

    # Open the image file
    img = PilImage.open(image.image.path)
    image_properties = {
        'type': img.format,
        'orientation': 'Landscape' if img.width > img.height else 'Portrait',
        'height': img.height,
        'width': img.width,
        'mode': img.mode,
        'size': img.size
    }

    # Extract properties for similar images
    similar_images = Image.objects.exclude(pk=pk).filter(
        Q(title__icontains=image.title.split()[0]) | Q(title__icontains=image.title.split()[-1])
    )
    similar_image_properties = []
    for sim_image in similar_images:
        sim_img = PilImage.open(sim_image.image.path)
        properties = {
            'image': sim_image,
            'type': sim_img.format,
            'orientation': 'Landscape' if sim_img.width > sim_img.height else 'Portrait',
            'height': sim_img.height,
            'width': sim_img.width,
            'mode': sim_img.mode,
            'size': sim_img.size
        }
        similar_image_properties.append(properties)

    # Sort similar images based on the selected option
    sort_option = request.GET.get('sort', 'default')
    if sort_option == 'type':
        similar_image_properties.sort(key=lambda x: x['type'])
    elif sort_option == 'color':
        similar_image_properties.sort(key=lambda x: x['mode'])
    elif sort_option == 'size':
        similar_image_properties.sort(key=lambda x: x['size'])
    elif sort_option == 'orientation':
        similar_image_properties.sort(key=lambda x: x['width'] / x['height'])

    form = CommentForm()

    if request.method == 'POST':
        if 'like' in request.POST:
            if user_dislike:
                Dislike.objects.filter(image=image, user=request.user).delete()
            if not user_like:
                Like.objects.create(image=image, user=request.user)
        elif 'dislike' in request.POST:
            if user_like:
                Like.objects.filter(image=image, user=request.user).delete()
            if not user_dislike:
                Dislike.objects.create(image=image, user=request.user)
        elif 'comment' in request.POST:
            form = CommentForm(request.POST)
            if form.is_valid():
                comment = form.save(commit=False)
                comment.image = image
                comment.user = request.user
                comment.save()
                return redirect('image_detail', pk=image.pk)

    return render(request, 'gallery/image_detail.html', {
        'image': image,
        'image_properties': image_properties,
        'similar_image_properties': similar_image_properties[:5],  # Limit to 5 similar images
        'comments': comments,
        'form': form,
        'user_like': user_like,
        'user_dislike': user_dislike,
        'total_likes': image.likes.count(),
        'total_dislikes': image.dislikes.count(),
        'sort_option': sort_option,
    })

@login_required
def edit_image(request, pk):
    image = get_object_or_404(Image, pk=pk)
    if request.user != image.author:
        return redirect('image_detail', pk=pk)
    
    existing_titles = Image.objects.values_list('title', flat=True).distinct()
    
    if request.method == 'POST':
        form = ImageForm(request.POST, request.FILES, instance=image, existing_titles=existing_titles)
        if form.is_valid():
            form.save()
            return redirect(image.get_absolute_url())
    else:
        form = ImageForm(instance=image, existing_titles=existing_titles)
    
    return render(request, 'gallery/edit_image.html', {'form': form, 'image': image})

@login_required
def delete_image(request, pk):
    image = get_object_or_404(Image, pk=pk)
    if request.user != image.author:
        return redirect('image_detail', pk=pk)
    
    if request.method == 'POST':
        image.delete()
        return redirect('image_list')
    
    return render(request, 'gallery/confirm_delete.html', {'image': image})

from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from .forms import ImageForm
from .models import Image

@login_required
def image_upload(request):
    if request.method == 'POST':
        form = ImageForm(request.POST, request.FILES, existing_titles=Image.objects.values_list('title', flat=True).distinct())
        if form.is_valid():
            image = form.save(commit=False)
            image.author = request.user
            image.save()
            return redirect('image_list')
    else:
        form = ImageForm(existing_titles=Image.objects.values_list('title', flat=True).distinct())
    
    return render(request, 'gallery/image_upload.html', {'form': form})
